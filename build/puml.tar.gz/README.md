# Puml: an PHP UML generator

Puml is an PHP UML generator, which aids in reverse enginering and in a refactoring process. It allows you to generate the UML scheme for an object. Given that you take care of the autoloader.

## Features
* Multiple outputs (PNG, DOT)
* Inheritance support

## Author
* [Danny van der Sluijs](http://www.dannyvandersluijs.nl) (Creator, Developer)

## License
* [New BSD license](http://www.opensource.org/licenses/bsd-license.php)

## Todo

## Requirements

## Installing

## Contributing

## Further information
